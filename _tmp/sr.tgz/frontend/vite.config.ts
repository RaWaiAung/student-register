import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // for `npm run dev` outside Docker
    proxy: { '/api': 'http://localhost:3000' },
  },
})
