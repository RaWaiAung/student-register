import { useEffect, useState, type FormEvent } from 'react'
import './App.css'

type Student = { id: number; name: string; createdAt: string }

const API = '/api/students'

function App() {
  const [students, setStudents] = useState<Student[]>([])
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  async function loadStudents() {
    const res = await fetch(API)
    setStudents(await res.json())
  }

  useEffect(() => {
    loadStudents().catch(() => setMessage('Could not load students'))
  }, [])

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    try {
      const res = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, password }),
      })
      const data = await res.json()
      if (!res.ok) {
        const msg = Array.isArray(data.message) ? data.message.join(', ') : data.message
        throw new Error(msg || 'Register failed')
      }
      setMessage(`Registered ${data.name}`)
      setName('')
      setPassword('')
      await loadStudents()
    } catch (err) {
      setMessage((err as Error).message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="container">
      <h1>Student Register</h1>

      <form onSubmit={handleSubmit} className="card">
        <label>
          Name
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            minLength={6}
            required
          />
        </label>
        <button type="submit" disabled={loading}>
          {loading ? 'Saving...' : 'Register'}
        </button>
        {message && <p className="message">{message}</p>}
      </form>

      <section className="card">
        <h2>All Students ({students.length})</h2>
        {students.length === 0 ? (
          <p>No students yet.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Registered</th>
              </tr>
            </thead>
            <tbody>
              {students.map((s) => (
                <tr key={s.id}>
                  <td>{s.id}</td>
                  <td>{s.name}</td>
                  <td>{new Date(s.createdAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </main>
  )
}

export default App
